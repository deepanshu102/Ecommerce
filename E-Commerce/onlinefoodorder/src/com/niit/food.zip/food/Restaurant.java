package com.niit.food;

import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Restaurant {

	public String getRestaurantName() {
		return RestaurantName;
	}

	public void setCustomerName(String RestaurantName) {
		this.RestaurantName = RestaurantName;
	}

	public String getRestaurantAddress() {
		return RestaurantAddress;
	}

	public void setCustomerAddress(String RestaurantAddress) {
		this.RestaurantAddress = RestaurantAddress;
	}

	public String getRestaurantId() {
		return RestaurantId;
	}

	public void setCustomerPhone(String RestaurantId) {
		this.RestaurantId = RestaurantId;
	}

	public String getPassword() {
		return password;
	}

	public void setpassword(String password) {
		this.password = password;
	}

	public Restaurant() {
		super();
	}

	String RestaurantId;
	String RestaurantName;
	String RestaurantAddress;
	String password;
public PreparedStatement pst;
Scanner sc;

	public void registerRestaurant() {
		Connections.con = Connections.getMyConnection();
		sc = new Scanner(System.in);
		try {
			String stql = "insert into Restaurant values(?,?,?,?)";
			System.out.println("Enter your ID");
			RestaurantId = sc.next();
			System.out.println("Enter your Name");
			RestaurantName = sc.next();
			System.out.println("Enter your Address");
			RestaurantAddress = sc.next();
			System.out.println("Enter your Password");
			password = sc.next();
			pst = Connections.con.prepareStatement(stql);
			pst.setString(1, RestaurantId);
			pst.setString(2, RestaurantName);
			pst.setString(3, RestaurantAddress);
			pst.setString(4, password);

			int cnt = pst.executeUpdate();
			if (cnt != -1)
				System.out.println("Registered");
			else
				System.out.println("Failed");
			Connections.con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}

	}
	public void login() {
		try {
			String RestaurantId, password;
			sc = new Scanner(System.in);
			System.out.println("Enter PhoneNo.: ");
			RestaurantId = sc.next();
			System.out.println("Enter Password: ");
			password = sc.next();
			Connections.con = Connections.getMyConnection();
			CallableStatement cst = Connections.con
					.prepareCall("{ call login(?,?)}");
			cst.setString(1, RestaurantId);
			cst.setString(2, password);
			ResultSet rs = cst.executeQuery();
			if (rs.next()) {
				System.out.println("Welcome: " + rs.getString(1));
			} else {
				System.out.println("PhoneNo. or Password Is Incorrect");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}

	public static void main(String[] arg) {
		Customer obj = new Customer();
		// obj.setInput();
		obj.registerRestaurant();
		obj.login();
	}
}
