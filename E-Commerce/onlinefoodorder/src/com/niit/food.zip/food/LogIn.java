package com.niit.food;

import java.util.*;

public class LogIn {

	String login_id ;
	String passwaord;
	
	
	private void adminLogin(){
		
	}
	
	private void customerLogin(){
		
		
		
	}
	
	
	
	
	
	public void login(){
		Scanner s = new Scanner(System.in);
		int choice = s.nextInt();
			
		switch(choice){
			case 1 :
				adminLogin();
				break;
			case 2:
				customerLogin();
				break;
			 default:
				// Invalid User;
		}
		
	}

}
