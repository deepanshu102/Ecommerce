package com.niit.food;

import java.util.*;

public class FoodOrder extends Food {
	
	Scanner s = new Scanner(System.in);
	
	public static int getOrderId() {
		return orderId;
	}

	public static void setOrderId(int orderId) {
		FoodOrder.orderId = orderId;
	}

	public boolean isCancelStatus() {
		return cancelStatus;
	}

	public void setCancelStatus(boolean cancelStatus) {
		this.cancelStatus = cancelStatus;
	}

	public int getFoodQuantity() {
		return foodQuantity;
	}

	public void setFoodQuantity(int foodQuantity) {
		this.foodQuantity = foodQuantity;
	}

	protected static int orderId;
	private boolean cancelStatus;
	int foodQuantity;
	
	public void orderDetails(){
		
	}
		
	public int addItems(){
		 {
			return orderId;
		}
	}
	
	public void deleteItems(){
		
	}
	
	public void updateItems(){
		
	}
}