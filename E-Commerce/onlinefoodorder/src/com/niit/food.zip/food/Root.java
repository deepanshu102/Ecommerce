package com.niit.food;

import java.util.*;

public class Root {

	public static void main(String[] args) {
		System.out.println("Welcome Foodie");
		System.out.println("Enter your choice to proceed further!");
		System.out.println("1) New User");
		System.out.println("2)Already Registered");
		int choice;
		Scanner s = new Scanner(System.in);
		{

			choice = s.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Please get yourself Registered");
				System.out.println("1)Register As Customer");
				System.out.println("2)Register As Restaurant");
				{
					String option;
					option = s.next();
					switch (option) {
					case "a":
						System.out.println("abc");
					
								
								
								
								
								
								
								
								
								
								
								
								
								
								
							
					case "b":
						System.out.println("bhg");
						break;
					}
				}
				break;

			case 2:
				System.out.println("Hey Buddy! Please Enter your details");
				System.out.println("1)Register As Customer");
				System.out.println("2)Register As Restaurant");
				break;
			default:
				System.out.println("ok,bye!");
			}
		}
	}
}
