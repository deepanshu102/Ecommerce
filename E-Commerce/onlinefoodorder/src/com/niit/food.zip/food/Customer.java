package com.niit.food;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Customer {
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	PreparedStatement pst;

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

	String customerId;
	String customerName;
	String customerAddress;
	String password;
	Scanner sc;

	public void registerCustomer() {
		Connections.con = Connections.getMyConnection();
		sc = new Scanner(System.in);
		try {
			String stql = "insert into Customer values(?,?,?,?)";
			System.out.println("Enter your ID");
			customerId = sc.next();
			System.out.println("Enter your Name");
			customerName = sc.next();
			System.out.println("Enter your Address");
			customerAddress = sc.next();
			System.out.println("Enter your Password");
			password = sc.next();
			pst = Connections.con.prepareStatement(stql);
			pst.setString(1, customerId);
			pst.setString(2, customerName);
			pst.setString(3, customerAddress);
			pst.setString(4, password);

			int cnt = pst.executeUpdate();
			if (cnt != -1)
				System.out.println("Registered");
			else
				System.out.println("Failed");
			Connections.con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}

	}

	public void login() {
		try {
			String customerId, password;
			sc = new Scanner(System.in);
			System.out.println("Enter PhoneNo.: ");
			customerId = sc.next();
			System.out.println("Enter Password: ");
			password = sc.next();
			Connections.con = Connections.getMyConnection();
			String sql="select * from customer where customerId=? and password=?";
			pst = Connections.con
					.prepareStatement(sql);
			pst.setString(1, customerId);
			pst.setString(2, password);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				System.out.println("Welcome: " + rs.getString(1));
			} else {
				System.out.println("PhoneNo. or Password Is Incorrect");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	public void forgetPassword(){
		try {
			String stql = "update customer set password=? where customerId=?";
			System.out.println("Enter your Phone Number");
			customerId = sc.next();
			System.out.println("Enter New Password");
			password = sc.next();
			pst = Connections.con.prepareStatement(stql);
			pst.setString(1, customerId);
			pst.setString(2, password);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				System.out.println("Password succesfully changed " + rs.getString(1));
			} else {
				System.out.println("PhoneNo. is Incorrect");
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
	}

	public static void main(String[] arg) {
		Customer obj = new Customer();
		//obj.registerCustomer();
		obj.login();
		obj.forgetPassword();
	}

	
}
