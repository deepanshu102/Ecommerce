package com.niit.food;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.*;

public class Food {

	Scanner s = new Scanner(System.in);
	protected static int foodId = 1;
	String foodName;
	Scanner sc;
	PreparedStatement pst;

	public void getItem() {

		foodId = 1;
		foodName = s.next();

		foodId++;
	}

	public void foodInsertion() {
		Connections.con = Connections.getMyConnection();
		sc = new Scanner(System.in);
		try {
			String stql = "insert into Food(foodName) values(?)";
			System.out.println("Enter Food Name");
			foodName = sc.next();
			pst = Connections.con.prepareStatement(stql);

			pst.setString(1, foodName);
			int cnt = pst.executeUpdate();
			if (cnt != -1)
				System.out.println("Food Succesfully Entered");
			else
				System.out.println("Failed");
			Connections.con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

	public static void main(String[] arg) {
		Food obj = new Food();
		obj.foodInsertion();

	}
}